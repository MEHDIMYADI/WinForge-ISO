Put signed, complete drivers (.inf + .sys + .cat) into these folders, then zip the three folders
(OS, WinPE, ALL at the archive root) and pass its https URL as "drivers_url".

OS\     added to install.wim only
WinPE\  added to boot.wim only (and winre.wim for client builds)
ALL\    added to both
